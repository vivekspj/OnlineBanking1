package com.cg.project.adminuserbean.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.project.bean.AdminUser;

public class AdminTest {

	AdminUser au = new AdminUser();
	@Test
	public void testusername() {
		au.setUserid(8886);
		assertEquals(8886, au.getUserid());
	}
	
	public void testusername1()
	{
		au.setUserid(888);
		assertNotEquals(888, au.getUserid());
	}

}
