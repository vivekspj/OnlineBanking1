package com.cg.project.bankuserbean.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class BankUserTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
