package com.cg.OnlineBanking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;
import com.capg.project.dao.ILoginDAO;
import com.capg.project.dao.LoginDAOImpl;

public class LoginTest {

	LoginBean bu = new LoginBean();
	ILoginDAO dao = new LoginDAOImpl();
	@Test
	public void testLogin() throws OnlineBankingException {
		bu.setUserName("8866");
		bu.setPassword("user1");
		assertEquals(0, dao.login(bu));
		//fail("Not yet implemented");
	}
	public void testLogin1() throws OnlineBankingException {
		bu.setUserName("8868");
		bu.setPassword("user1");
		assertEquals(0, dao.login(bu));
		//fail("Not yet implemented");
	}
	
}
