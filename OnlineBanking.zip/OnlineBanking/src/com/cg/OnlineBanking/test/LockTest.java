package com.cg.OnlineBanking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.dao.ILockStatusDAO;
import com.capg.project.dao.LockStatusDAOImpl;

public class LockTest {

	@Test
	public void testLockAccount() throws OnlineBankingException {
		ILockStatusDAO tdao = new  LockStatusDAOImpl();
		assertEquals(1,tdao.lockAccount("8867"));
		
		//fail("Not yet implemented");
	}
	public void testLockAccount2() throws OnlineBankingException {
		ILockStatusDAO tdao = new  LockStatusDAOImpl();
		assertEquals(1,tdao.lockAccount("8868"));
		
		//fail("Not yet implemented");
	}

}
