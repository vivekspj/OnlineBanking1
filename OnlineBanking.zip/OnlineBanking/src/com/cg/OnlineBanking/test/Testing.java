package com.cg.OnlineBanking.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.IUserDAO;
import com.capg.project.dao.UserImpDAO;

public class Testing {

	IUserDAO dao = new UserImpDAO();
	@Test
	public void testChangeInCommunicationAddressBankUser() throws OnlineBankingException {
		BankUser bu = new BankUser();
		bu.setUserName("8866");
		
		assertEquals(0, dao.changeInCommunicationAddress(bu));
		
		assertNotEquals(1,  dao.changeInCommunicationAddress(bu));
	}

	@Test
	public void testChangeInCommunicationAddressStringStringString() throws OnlineBankingException {
		assertEquals(1, dao.changeInCommunicationAddress("8866", "Capgemini,Sipcot It Park", "8904678987"));
		assertNotEquals(1, dao.changeInCommunicationAddress("88", "Capgemini,Sipcot It Park", "8904678987"));
	}

	@Test
	public void testChequeBookRequest() throws OnlineBankingException {
		/*
		BankUser bu1 = new BankUser();
		bu1.setUserName("1000");
		bu1.setServiceDescription("New Cheque Book");
		assertEquals(42, dao.chequeBookRequest(bu1));*/
		
		BankUser bu = new BankUser();
		bu.setUserName("8866");
		bu.setServiceDescription("New Cheque Book");
		assertNotEquals(43, dao.chequeBookRequest(bu));
	}

	@Test
	public void testTrackServiceRequest() throws OnlineBankingException {
		BankUser bu = new BankUser();
		bu.setUserName("8866");
		assertNotEquals("open", dao.trackServiceRequest(bu));
		
		bu.setUserName("8886");
		assertNotEquals("open", dao.trackServiceRequest(bu));
	}


}
