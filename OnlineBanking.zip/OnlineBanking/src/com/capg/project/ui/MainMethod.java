package com.capg.project.ui;

import java.util.*;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.bean.LoginBean;
import com.capg.project.service.AdminServiceImpl;
import com.capg.project.service.IAdminService;
import com.capg.project.service.ILoginService;
import com.capg.project.service.IUserService;
import com.capg.project.service.LoginServiceImpl;
import com.capg.project.service.UserServiceImpl;

public class MainMethod  {

	static Logger log = Logger.getRootLogger();
	
	static int count=0;
	public static void main(String[] args) throws OnlineBankingException {
		BankUser bu = new BankUser();
		AdminUser au = new AdminUser();
		IUserService service=new UserServiceImpl();
		IAdminService service1 = new AdminServiceImpl();
		ILoginService loginService = new LoginServiceImpl();
		LoginBean login1 = new LoginBean();
		 int i;
		 String newpassword;
		 String oldpassword;String pass,userid;
		 int n=0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		do{
			//Read Username from user
			System.out.println("Enter UserName:");
			userid=sc.next();
			login1.setUserName(userid);
			bu.setUserName(userid);
			//Read Password from user
			System.out.println("Enter Password:");
			pass=sc.next();
			login1.setPassword(pass);
			//setting password to bean object
			bu.setPassword(pass);
			
			try {
				if(loginService.login(login1)==0)
				{
					System.out.println("Your Account Balance is:"+login1.getBalance());
					char j='N';
					do {//Displaying  the Menu
						System.out.println("Login Successful");
						System.out.println("1. Change In Communication Address:");
						System.out.println("2. Request For Cheque Book:");
						System.out.println("3. Track  Service Request:");
						System.out.println("4. Fund Transfer:");
						System.out.println("5. Change Password:");
						
						System.out.println("6. Mini Statement:");
						System.out.println("Enter your choice: ");
						i=sc.nextInt();
						switch(i) 
						{
							case 1:
								String number="";boolean num = false;
								BankUser bu3 = new BankUser();String addr="";
								System.out.println("Your Communication Address is:");
								bu3.setUserName(userid);
								service.changeInCommunicationAddress(bu3);/*Calling the changeInCommunicationAddress from service layer*/
								System.out.println("Your current address id:"+bu3.getCusaddr());
								System.out.println("Your current mobile number is:"+bu3.getMobileNumber());
								do{
									System.out.println("Enter New Address");
									addr = sc.next();
									if(addr.matches("[0-9a-zA-Z\t]+"))
									{
										System.out.println("Enter New MobileNumber");
										do{
											number = sc.next();
											//Mobile Number Validation
											if(number.length()==10)
											{
												num=number.matches("[6789]{1}[0-9]{9}");
												if(num==true)
												{
													n = service.changeInCommunicationAddress(userid,addr,number);
														log.info(n+" Row Updated");
														System.out.println(n+" Row Updated");
												}
												else
												{
													log.error("No Row Updated.");
													System.out.println("Please enter only Number:");
												}
											}
											else
											{
												log.error("No Row Updated.");
												System.out.println("Please enter 10 digit number:");
											}
									
										}while(number.length()!=10 || num==false);
									}
									else
									{
										log.error("No Row Updated.");
										System.out.println("Please enter valid address");
									}
									
									
								}while(addr.matches("[a-zA-Z\t]+") == false);
								
								break;
								
							case 2:String desc="";
								System.out.println("Enter desc");
								desc = sc.next();
								bu.setServiceDescription(desc);
								int sid1 = service.chequeBookRequest(bu);
								if(sid1 !=0)
								{
									System.out.println("Your Service request is generated and "
											+ "your service_id is "+sid1);
									log.info("1 Row Updated in Service_Tracker Table.");
								}
								else
								{
									log.error("No row updated.");
									System.err.println("Your Previous Cheque Book Request is Already in Open State And It Will Be Dispatched Soon.");
								}
								
								break;
							case 3:int sid=0;
								String status="";
								do{
									System.out.println("Enter Your Serviceid:");
									sid=sc.nextInt();
									BankUser bu2 = new BankUser();
									bu2.setServiceId(sid);
									bu2.setUserName(userid);
									status = service.trackServiceRequest(bu2);
									if(status != null)
									{
										System.out.println("Status is: "+ status);
									}
									if(status == null)
									{
										log.error("Wrong Service Id Entered.");
										System.out.println("please enter correct serviceTracker ID");
									}
								}while(status == null);
								
									
								break;
							
							case 4:String transfer_Amount="";String payeeAccount_id="";
							int payeeAccountid =0;long transferAmount=0;
								BankUser bu1= new BankUser();
								System.out.println("\nEnter PayeeAccount :");
								do{
									
									payeeAccount_id=sc.next();
									if(payeeAccount_id.matches("[0-9]+"))
									{
										payeeAccountid = Integer.parseInt(payeeAccount_id);
										bu1.setPayeeAccount(payeeAccountid);
										System.out.println("Enter Amount to be transfered:");
										do{
											
											transfer_Amount=sc.next();
											if(transfer_Amount.matches("[1-9]{1}[0-9]*"))
											{
												transferAmount = Long.parseLong(transfer_Amount);
												bu1.setTransferAmount(transferAmount);
												long newBalance = login1.getBalance() - transferAmount;
												bu1.setNewBalance(newBalance);
												System.out.println("Enter Transaction_Password:");
												String transaction_Password = sc.next();
												au.setTransactionpassword(transaction_Password);
												n=service.fundTransfer(userid,bu1,au);
												log.info(n+" Row Updated.");
												System.out.println(n+ " Rows Updated.");
											}
											else
											{
												log.error("Wrong Amount Entered.");
												System.err.println("Enter valid amount again:");
											}
											
										}while(transferAmount<=0);
										
									}
									else
									{
										log.error("Wrong AccountId Format.");
										System.err.println("Please enter only number again:");
									}
								}while(!payeeAccount_id.matches("[0-9]+"));
								break;
							
							case 5:String newpassword1="";int l1=0,l2=0;
								System.out.println("Enter Current Password:");
								do{
									oldpassword=sc.next();
									
									do{
										System.out.println("\nEnter new Password:");
										newpassword=sc.next();
										l1=newpassword.length();//length of newPassword
										System.out.println("Enter new Password:");
										newpassword1=sc.next();
										l2=newpassword1.length();//length of NewPassword1
										if(newpassword1.equals(newpassword) && oldpassword.equals(pass) && l1==l2)
										{
											
											userid=bu.getUserName();
											n=service.changePassword(newpassword,userid);
											if(n<=0)
											{
												log.error("User entering  password used in past.");
												System.err.println("Please enter a new password which you have not used before.");
											}
											else
											{
												log.info(n+" Row Updated.");
												System.out.println(n+" Row Updated.");
											}
											
										}
										else if(!newpassword1.equals(newpassword))
										{
											log.error("Both newpassword didn't match");
											System.err.println("Both newpassword didn't match");
										}
										else if(l1 != l2)
										{
											log.error("Password length must be greater than equal to 8. ");
											System.err.println("Password length must be greater than equal to 8.");
										}
										else
										{
											System.err.println("Please enter correct current password");
										}
										
									}while(!newpassword1.equals(newpassword) || l1 != l2);
									
								}while( !oldpassword.equals(pass) );
						   
						    break;
							case 6:
								int duration=0;
								System.out.println("Select Duration:");
								System.out.println("1. Press 1 to get miniStatement(Last 10 days)");
								System.out.println("2. Press 2 to get miniStatement Monthly");
								System.out.println("3. Press 3 to get miniStatement Yearly");
								duration=sc.nextInt();
								int tranDuration=0;
								switch(duration)
								{
								case 1: tranDuration=10;
								
								break;
								
								case 2: tranDuration=30;
								break;
								
								case 3: tranDuration=365;
								break;
								
								default: System.out.println("please select proper duration.");;
								break;
								}
								BankUser bu4 = new BankUser();
								
								//bu4.setCusid(account_id1);
								//bu4.setTranDuration(tranDuration);
								
								ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
								arrayList = service.viewMiniStatement(tranDuration,userid);
								if(arrayList.isEmpty())
								{
									log.info("No transaction to show.");
									System.err.println("Sorry there is no transaction to display.");
								}
								else
								{
									System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
											+ "TransactionType |  TranAmount  |  Account_No");
									System.out.println("----------------------------------------------------------"
											+ "------------------------------------------");
									for(BankUser b1:arrayList)
									{
										System.out.println(b1.getTransaction_ID()+" 		|	"+b1.getTran_Description()
												+"	 |	"+b1.getDateofTransaction()+"	|	"+b1.getTransactionType()
												+"	 |	"+b1.getTransferAmount()+"  	|	"+b1.getCusid());
									}
								
									
								}
								
								break;
							default: System.out.println("Thanks for Visiting");
							break;
						}
						
						System.out.println("Press 'Y' to continue and 'N' to exit");
						j=sc.next().charAt(0);
					}while(j == 'Y' || j=='y');

				}
				else if(loginService.login(login1)==1)
				{
					char j='N';
					do{
						System.out.println("1. Create New Account:");
						System.out.println("2. View transactions of all accounts:");
						i=sc.nextInt();
						switch(i) 
						{
						case 1:String customerName="",customeremail="",customeraddress="",mobileNumber="";
								boolean email=false;
									System.out.println("\nEnter Your Full Name");
								
								do{
									String s=sc.nextLine();
									customerName=sc.nextLine();
									if(customerName.matches("[a-zA-z\\s]+[a-zA-z]*"))
									{
										System.out.println("Enter Your Email");
										do{
											customeremail=sc.next();
											String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
													"[a-zA-Z0-9_+&*-]+)*@" +
													 "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
													"A-Z]{2,7}$";
											Pattern pat = Pattern.compile(emailRegex);
											email =pat.matcher(customeremail).matches();
											if(email == true) {
												System.out.println("Enter Your Address");
												do{
													String st=sc.nextLine();
													customeraddress=sc.nextLine();
													if(customeraddress.matches("[a-zA-Z0-9\\s]+"))
													{
														System.out.println("Enter Your Mobile number");
														boolean num = false;
														String accountType="";
														do{
															mobileNumber=sc.next();
															if(mobileNumber.length()==10)
															{
																num=mobileNumber.matches("(0/91)?[7-9][0-9]{9}");
																if(num==true)
																{
																	au.setCustomerName(customerName);
																	au.setCustomeremail(customeremail);
																	au.setCustomeraddress(customeraddress);
																	au.setMobileNumber(mobileNumber);
																	
																	
																	int openingBalance;
																	System.out.println("Enter aacount_type Saving/Current");
																	
																	do{
																		accountType=sc.next();
																		if(accountType.equalsIgnoreCase("saving") || accountType.equalsIgnoreCase("deposit"))
																		{
																			au.setAccountType(accountType);
																			System.out.println("Enter Opening balance");
																			openingBalance=sc.nextInt();
																			if(openingBalance>=0)
																			{
																				au.setOpeningBalance(openingBalance);
																				String securityQuestion="",securityAnswer="";
																				System.out.println("Enter Security question and answer");
																				securityQuestion=sc.next();
																				securityAnswer=sc.next();
																				au.setSecurityQuestion(securityQuestion);
																				au.setSecurityAnswer(securityAnswer);
																				int account_id = service1.createNewAccount(au);
																				System.out.println("Your Account Id id "+account_id);
																			}
																			else
																			{
																				log.error("Invalid Amount Entered.");
																				System.err.println("Please enter valid Balance");
																			}
																			
																		}
																		else
																		{
																			log.error("Wrong Account Type Entered.");
																			System.err.println("Either enter saving or deposit");
																		}
																	}while(!accountType.equalsIgnoreCase("saving") || !accountType.equalsIgnoreCase("current"));
																	
																}
																else
																{
																	System.out.println("Please enter only Number:");
																}
															}
															else
															{
																System.out.println("Please enter 10 digit number:");
															}
															
															
														}while(mobileNumber.length()!=10 || num ==false);
														
													}
													else
													{
														log.error("Characters other than whitespace,number and alphabets entered.");
														System.err.println("Special Characters are not allowed.");
													}
												}while(!customeraddress.matches("[a-zA-Z0-9\\s]+"));
																								
											}
											else {
											System.out.println("Enter valid email id");
											System.out.println("");
											}
											
										}while(email==false);
									}
									else
									{
										log.error("Wrong Customername format.");
										System.err.println("Please enter only alphabets.");
									}
									
								}while(!customerName.matches("[a-zA-z\\s]+[a-zA-z]*"));
							
							break;
							
						case 2:String accountid1="";int duration=0, account_id1=0;
						BankUser bu1 = new BankUser();
								System.out.println("\nEnter Account Id for getting Transaction of accountid");
								do{
									accountid1 = sc.next();
									if(accountid1.matches("[1-9]{1}[0-9]+"))
									{
										account_id1=Integer.parseInt(accountid1);
										System.out.println("Select Duration:");
										System.out.println("1. Weekly");
										System.out.println("2. Monthly");
										System.out.println("3. Yearly");
										duration=sc.nextInt();
										int tranDuration=0;
										switch(duration)
										{
										case 1: tranDuration=7;
										
										break;
										
										case 2: tranDuration=30;
										break;
										
										case 3: tranDuration=365;
										break;
										
										default: System.out.println("please select proper duration.");;
										break;
										}
										BankUser bu4 = new BankUser();
										
										//bu4.setCusid(account_id1);
										//bu4.setTranDuration(tranDuration);
										
										ArrayList<BankUser> al = new ArrayList<BankUser>();
										al = service1.viewTransaction(account_id1,tranDuration);
										if(al.isEmpty())
										{
											System.err.println("Sorry there is no transaction to display.");
										}
										else
										{
											System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
													+ "TransactionType |  TranAmount  |  Account_No");
											System.out.println("----------------------------------------------------------"
													+ "------------------------------------------");
											for(BankUser b1:al)
											{
												System.out.println(b1.getTransaction_ID()+" 		|	"+b1.getTran_Description()
														+"	 |	"+b1.getDateofTransaction()+"	|	"+b1.getTransactionType()
														+"	 |	"+b1.getTransferAmount()+"  	|	"+b1.getCusid());
											}
										
											
										}
									}
									else
									{
										log.error("Please enter axccount in number.");
										System.err.println("Please enter Account number in digits only.");
									}
									
									
								}while(!accountid1.matches("[1-9]{1}[0-9]+"));
							break;
							
						default: System.out.println("Thanks for Visiting");
							
							break;
						}
						System.out.println("Press 'Y' to continue and 'N' to exit");
						j=sc.next().charAt(0);
					}while(j == 'Y' || j=='y');
					
					
				}
				else
				{
					++count;
					int left=3-count;
					if(count<3)
					{
						System.out.println("Incorrect Username or Password.");
						System.out.println("You have Entered Wrong UserName and Password "+count +" Time.");
						System.out.println("Your Account Will be Locked After "+left+" Attempts.");
						System.out.println("Please Enter Correct UserName and Password.");
					}
					if(count==3)
					{
						System.out.println("Your Account is Blocked. Please Contact Your Nearest Branch.");
					}
					
				}
			} catch (OnlineBankingException e) {
				
				throw new OnlineBankingException("problem : "+e.getMessage());
			}
		}while(count>0 && count<3);
		
	}
	
}