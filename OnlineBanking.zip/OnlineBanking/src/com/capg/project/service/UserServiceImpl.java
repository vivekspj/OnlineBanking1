package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.IUserDAO;
import com.capg.project.dao.UserImpDAO;

public class UserServiceImpl implements IUserService {
	BankUser bu =new BankUser();
	IUserDAO dao=new UserImpDAO();
	@Override
	public int login(String userid,String password)
			throws OnlineBankingException {
		
		return dao.login(userid, password);
	}

	@Override
	public int changeInCommunicationAddress(BankUser bu3)
			throws OnlineBankingException {
		
		return dao.changeInCommunicationAddress(bu3);
	}
	public int changeInCommunicationAddress(String userid,String addr,String number) throws OnlineBankingException
	{
		return dao.changeInCommunicationAddress(userid,addr,number);
		
	}

	@Override
	public int chequeBookRequest(BankUser bu) throws OnlineBankingException {
		return dao.chequeBookRequest(bu);
	}

	@Override
	public String trackServiceRequest(BankUser bu2)
			throws OnlineBankingException {
		return dao.trackServiceRequest(bu2);
		
	}

	@Override
	public int fundTransfer(String userid,BankUser bu1,AdminUser au) throws OnlineBankingException {
		// TODO Auto-generated method stub
		return dao.fundTransfer(userid,bu1,au);
	}

	@Override
	public int changePassword(String newpassword,String userid) throws OnlineBankingException {
		// TODO Auto-generated method stub
		return dao.changePassword(newpassword,userid);
	}

	@Override
	public ArrayList<BankUser> viewMiniStatement(BankUser bu4) throws OnlineBankingException {
		ArrayList<BankUser> al = new ArrayList<BankUser>();
		al = dao.viewMiniStatement(bu4);
		// TODO Auto-generated method stub
		return al;
	}

	

}
