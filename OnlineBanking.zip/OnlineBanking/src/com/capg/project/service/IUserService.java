package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;

public interface IUserService {
	 public int login(String userid,String password) throws OnlineBankingException;
	 public int changeInCommunicationAddress(BankUser bu3) throws OnlineBankingException;
	 public int changeInCommunicationAddress(String userid,String addr,String number) throws OnlineBankingException;
	 public int  chequeBookRequest(BankUser bu) throws OnlineBankingException;
	 public String trackServiceRequest(BankUser bu2) throws OnlineBankingException;
	 public int  fundTransfer(String userid,BankUser bu1,AdminUser au) throws OnlineBankingException;
	 public int changePassword(String newpassword,String userid) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewMiniStatement(BankUser bu4) throws OnlineBankingException;
}
