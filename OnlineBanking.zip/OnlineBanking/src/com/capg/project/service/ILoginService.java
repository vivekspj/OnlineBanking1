package com.capg.project.service;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;

public interface ILoginService {

	public abstract int login(LoginBean login1) throws OnlineBankingException;
}
