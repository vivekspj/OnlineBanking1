package com.capg.project.service;

import com.capg.project.bankexception.OnlineBankingException;

public interface ILockStatusService {
	public abstract int lockAccount(String userId) throws OnlineBankingException;

}
