package com.capg.project.service;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.dao.ILockStatusDAO;
import com.capg.project.dao.LockStatusDAOImpl;

public class LockStatusServiceImpl implements ILockStatusService {

	ILockStatusDAO dao = new LockStatusDAOImpl();
	@Override
	public int lockAccount(String userId) throws OnlineBankingException {
		
		return dao.lockAccount(userId);
	}

}
