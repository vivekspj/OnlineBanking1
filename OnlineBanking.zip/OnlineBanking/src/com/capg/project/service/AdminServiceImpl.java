package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.AdminDAOImpl;
import com.capg.project.dao.IAdminDAO;

public class AdminServiceImpl implements IAdminService {

	IAdminDAO admindao=new AdminDAOImpl();
	@Override
	public int createNewAccount(AdminUser au) throws OnlineBankingException {
		return admindao.createNewAccount(au);
	}

	@Override
	public ArrayList<BankUser> viewTransaction(int account_id1,int tranDuration)
			throws OnlineBankingException {
		ArrayList<BankUser> al = new ArrayList<BankUser>();
		al = admindao.viewTransaction(account_id1,tranDuration);
		// TODO Auto-generated method stub
		return al;
	}


}
