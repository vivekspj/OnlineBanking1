package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;

public interface IAdminService {
	public int createNewAccount(AdminUser au) throws OnlineBankingException;
	 public ArrayList<BankUser> viewTransaction(int account_id1,int tranDuration) throws OnlineBankingException;
	

}
