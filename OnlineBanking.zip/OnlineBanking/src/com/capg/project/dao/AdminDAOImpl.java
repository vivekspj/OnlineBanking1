package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.dbutil.DBUtil;

public class AdminDAOImpl implements IAdminDAO {

	static Logger log = Logger.getRootLogger();
	int n=0;
	ResultSet rs = null;
	@Override
	public int createNewAccount(AdminUser au) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		int aid = 0;
		try{
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.insertIntoCustomer);
			pstmt.setString(1, au.getCustomerName());
			pstmt.setString(2,au.getCustomeremail());
			pstmt.setString(3,au.getCustomeraddress());
			pstmt.setString(4, au.getMobileNumber());
			 n = pstmt.executeUpdate();
			 //System.out.println("done2");
			 PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.insertIntoAccountMaster);
			 pstmt1.setString(1,au.getAccountType());
			 pstmt1.setLong(2,au.getOpeningBalance());
			 
			n= n+ pstmt1.executeUpdate();
			//System.out.println("done3");
			 PreparedStatement pstmt3 = conn.prepareStatement(IQueryMapper.insertIntoUserTable);
			 pstmt3.setString(1, au.getSecurityQuestion());
			 pstmt3.setString(2, au.getSecurityAnswer());
			 n=n+pstmt3.executeUpdate();
			 //System.out.println("done4");
			 
			 PreparedStatement pstmt2 = conn.prepareStatement(IQueryMapper.selectAccSeq);
			 rs=pstmt2.executeQuery();
			 while(rs.next())
			 {
				 aid = rs.getInt(1);
			 }
			
		}
		catch(SQLException e){
			log.error("Problem in account creation.");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return aid;
	}

	@Override
	public ArrayList<BankUser> viewTransaction(long account_id1,int tranDuration) throws OnlineBankingException
	{
		Connection conn=DBUtil.getConn();
		ArrayList<BankUser> arrayList = new ArrayList<BankUser>();
		try{
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.selectAllFromTransaction);
			pstmt.setLong(1,account_id1);
			pstmt.setInt(2,tranDuration);
			rs=pstmt.executeQuery();
			while(rs.next()){
				BankUser bu4=new BankUser();
				int transaction_ID = rs.getInt(1);
				String tran_Description = rs.getString(2);
				Date dateofTransaction = rs.getDate(3);
				String transactionType = rs.getString(4);
				int transferAmount = rs.getInt(5);
				int account_No = rs.getInt(6);
				bu4.setTransaction_ID(transaction_ID);
				bu4.setTran_Description(tran_Description);
				bu4.setDateofTransaction(dateofTransaction);
				bu4.setTransactionType(transactionType);
				bu4.setCusid(account_No);
				bu4.setTransferAmount(transferAmount);
				
				arrayList.add(bu4);
			}
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return arrayList;
	}


}
