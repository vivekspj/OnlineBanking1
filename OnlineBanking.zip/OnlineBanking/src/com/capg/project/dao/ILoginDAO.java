package com.capg.project.dao;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;

public interface ILoginDAO {
	
	public abstract int login(LoginBean login1) throws OnlineBankingException;

}
