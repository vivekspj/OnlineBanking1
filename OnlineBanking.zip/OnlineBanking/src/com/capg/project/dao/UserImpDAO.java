package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.bean.LoginBean;
import com.capg.project.dbutil.DBUtil;
import com.capg.project.ui.MainMethod;


public class UserImpDAO implements IUserDAO {
	
	BankUser bu = new BankUser();
	MainMethod m = new MainMethod();
	AdminUser au =new AdminUser();

	int n=0;
	int c=0;
	ResultSet rs =null;
	
	

	@Override
	public int changeInCommunicationAddress(BankUser bu3) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		try {
			String selectQuery="select account_id from user_table where user_id=?";
			PreparedStatement pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, bu3.getUserName());
			rs=pstmt.executeQuery();
			rs.next();
			int accId=rs.getInt(1);
			
			PreparedStatement pstmt1 = conn.prepareStatement("select Address,MobileNumber from CUSTOMER where Account_ID =?");
			pstmt1.setInt(1, accId);
			rs=pstmt1.executeQuery();
			
			rs.next();
				bu3.setCusaddr(rs.getString(1));
				bu3.setMobileNumber(rs.getString(2));
		} catch (SQLException e1) {
			throw new OnlineBankingException("problem : "+e1.getMessage());
		}
		return n;

	}
	public int changeInCommunicationAddress(String userid,String addr,String number) throws OnlineBankingException
	{
		Connection conn=DBUtil.getConn();
		
		try{
			PreparedStatement ptst=conn.prepareStatement("Update customer SET Address=? , MobileNumber=? where Account_ID=(Select Account_ID from user_table where User_id=?)");
			ptst.setString(1, addr);
			ptst.setString(2, number);
			ptst.setString(3, userid);
			n=ptst.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return n;
	}

	@Override
	public int chequeBookRequest(BankUser bu) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		int sid=0;
		try
		{
			String selectQuery="select account_id from user_table where user_id=?";
			PreparedStatement pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, bu.getUserName());
			rs=pstmt.executeQuery();
			rs.next();
			int accId=rs.getInt(1);
			bu.setCusid(accId);
			
			PreparedStatement pst = conn.prepareStatement("Select Service_status from Service_Tracker where Account_ID =?");
			pst.setInt(1, accId);
			rs = pst.executeQuery();
			boolean val = false;
			while(rs.next())
			{
				if(rs.getString(1).equalsIgnoreCase("open"))
				{
					val = true;
				}
				break;
			}
			if(val == false)
			{
				String insertQuery = "INSERT into SERVICE_TRACKER values(Serv_id.NEXTVAL,?,?,sysdate,'Open')";
				PreparedStatement ptst = conn.prepareStatement(insertQuery);
				ptst.setString(1,bu.getServiceDescription());
				ptst.setInt(2,accId);
				n=ptst.executeUpdate();
				
				PreparedStatement ptst1=conn.prepareStatement("select Serv_id.currval from SERVICE_TRACKER");
				rs=ptst1.executeQuery();
				rs.next();
				sid=rs.getInt(1);
			}
			
		}
		catch(SQLException e)
		{
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		
		return sid;
	}

	@Override
	public String trackServiceRequest(BankUser bu2) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		String status="";
		int aid =0;
		try{
			PreparedStatement pst = conn.prepareStatement("select Account_ID from user_table where User_ID=?");
			pst.setString(1, bu2.getUserName());
			rs=pst.executeQuery();
			while(rs.next())
			{
				aid=rs.getInt(1);
			}
			
			PreparedStatement pstmt = conn.prepareStatement("Select Service_status from Service_Tracker where service_id=? and Account_ID =?");
			pstmt.setInt(1, bu2.getServiceId());
			pstmt.setInt(2, aid);
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				status=rs.getString(1);
			}
			if(status.equalsIgnoreCase("open"))
			{
				status = "Open";
			}
			else if(status.equalsIgnoreCase("dispatched"))
			{
				status = "Dispatched";
			}

			else if(status.equalsIgnoreCase("issued"))
			{
				status = "Issued";
			}

			else if(status.equalsIgnoreCase("returned"))
			{
				status = "Returned";
			}
			else
			{
				status = null;
			}

			
		}
		catch(SQLException e)
		{
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return status;

	}

	@Override
	public int fundTransfer(String userid ,BankUser bu1,AdminUser au) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();long newAccountBalance=0;
		try{
			String tp = "";
			int account_id=0;
			PreparedStatement pst = conn.prepareStatement("select * from User_Table where user_id=?");
			pst.setString(1,userid);
			rs=pst.executeQuery();
			while(rs.next())
			{
				tp = rs.getString(6);
				account_id=rs.getInt(1);
			}
			long bal = 0;
			if(tp.equals(au.getTransactionpassword()))
			{
				PreparedStatement pst1 = conn.prepareStatement("select * from Account_Master where Account_ID=?");
				pst1.setInt(1,account_id);
				ResultSet rs1=pst1.executeQuery();
				while(rs1.next())
				{
					 bal= rs1.getInt(3);
				}
				if(bal>bu1.getTransferAmount())
				{
					int i =0;
					PreparedStatement pstmt = conn.prepareStatement("select * from Payee_Table where Account_ID=?");
					pstmt.setInt(1,account_id);
					rs=pstmt.executeQuery();
					while(rs.next())
					{
						
						if(rs.getInt(2) == bu1.getPayeeAccount())
						{
							PreparedStatement select = conn.prepareStatement("select Customer_Name from customer where Account_ID = ? ");
							select.setInt(1,account_id);
							ResultSet rs11;
							rs11=select.executeQuery();
							rs11.next();
							String cusname = rs11.getString(1);
							
							PreparedStatement select1 = conn.prepareStatement("select Customer_Name from customer where Account_ID = ? ");
							select1.setInt(1,bu1.getPayeeAccount());
							ResultSet rs111;
							rs111=select1.executeQuery();
							String cusname1="";
							while(rs111.next())
							{
								 cusname1 = rs111.getString(1);
							}
							//System.out.println("resultset");
							if(cusname.equalsIgnoreCase(cusname1))
							{
								PreparedStatement pstmt1 = conn.prepareStatement("insert into Fund_Transfer values(Fundtrans_id.nextval,?,?,sysdate,?)");
								pstmt1.setInt(1,account_id);
								pstmt1.setInt(2, bu1.getPayeeAccount());
								pstmt1.setLong(3,bu1.getTransferAmount());
								
								n=pstmt1.executeUpdate();
								
								PreparedStatement pstmt2 = conn.prepareStatement("insert into Transactions values(tran_id.nextval,'Deposit',sysdate,'D',?,?)");
								pstmt2.setLong(1,bu1.getTransferAmount());
								pstmt2.setInt(2,account_id);
								
								n=n+pstmt2.executeUpdate();
								
								PreparedStatement pstmt3 = conn.prepareStatement("Update Account_Master SET Account_Balance = ? where Account_ID = ?");
								pstmt3.setLong(1,bu1.getNewBalance());
								pstmt3.setInt(2, account_id);
								
								n=n+pstmt3.executeUpdate();
							}
							else{
								if(bu1.getTransferAmount()<= 1000000)
								{
									PreparedStatement pstmt1 = conn.prepareStatement("insert into Fund_Transfer values(Fundtrans_id.nextval,?,?,sysdate,?)");
									pstmt1.setInt(1,account_id);
									pstmt1.setInt(2, bu1.getPayeeAccount());
									pstmt1.setLong(3,bu1.getTransferAmount());
									
									n=pstmt1.executeUpdate();
									
									PreparedStatement pstmt2 = conn.prepareStatement("insert into Transactions values(tran_id.nextval,'Deposit',sysdate,'D',?,?)");
									pstmt2.setLong(1,bu1.getTransferAmount());
									pstmt2.setInt(2,account_id);
									
									n=n+pstmt2.executeUpdate();
	 								
									PreparedStatement pstmt3 = conn.prepareStatement("Update Account_Master SET Account_Balance = ? where Account_ID = ?");
									pstmt3.setLong(1,bu1.getNewBalance());
									pstmt3.setInt(2, account_id);
									
									n=n+pstmt3.executeUpdate();
								}
								else
								{
									System.err.println("Please enter amount less than 10 Lakh");
								}
							}
							
							break;
						}
					}
					
				}
				else{
					System.err.println("Entered amount is greater the available balance.");
				}
			}
			
			
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		
		return n;
		

	}

	@Override
	public int changePassword(String newpassword,String userid) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		bu = new BankUser();
		String pass= "";
		try{
				PreparedStatement pstmt1 = conn.prepareStatement("select Login_Password from User_Table where user_id = ?");
				pstmt1.setString(1, userid);
				rs = pstmt1.executeQuery();
				while(rs.next())
				{
					pass= rs.getString(1);
				}
				if(!pass.equals(newpassword))
				{
					PreparedStatement pstmt = conn.prepareStatement("Update User_Table SET Login_Password = ? where user_id  = ?");
					pstmt.setString(1, newpassword);
					pstmt.setString(2, userid);
					
					n=pstmt.executeUpdate();
				}
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return n;	
	}


	@Override
	public ArrayList<BankUser> viewMiniStatement(BankUser bu4) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		ArrayList<BankUser> al = new ArrayList<BankUser>();
		int transaction_ID=0;
		try{
			int account_id=0;
			PreparedStatement pst = conn.prepareStatement("select * from User_Table where user_id=?");
			pst.setString(1,bu4.getUserName());
			rs=pst.executeQuery();
			while(rs.next())
			{
				account_id=rs.getInt(1);
			}
			PreparedStatement pstmt = conn.prepareStatement("select * from Transactions where Account_No=? and sysdate-DateofTransaction<=?");
			pstmt.setInt(1,account_id);
			pstmt.setInt(2,bu4.getTranDuration());
			rs=pstmt.executeQuery();
			while(rs.next()){
				transaction_ID = rs.getInt(1);
				
				String tran_Description = rs.getString(2);
				Date dateofTransaction = rs.getDate(3);
				String transactionType = rs.getString(4);
				int transferAmount = rs.getInt(5);
				int account_No = rs.getInt(6);
				bu4.setTransaction_ID(transaction_ID);
				bu4.setTran_Description(tran_Description);
				bu4.setDateofTransaction(dateofTransaction);
				bu4.setTransactionType(transactionType);
				bu4.setCusid(account_No);
				bu4.setTransferAmount(transferAmount);
				al.add(bu4);
			}
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		
		return al;
	}


}
