package com.capg.project.dao;

public interface IQueryMapper {
	public static final String login = "Select * from User_Table where user_id=? and login_password=?";
	public static final String selectAccountId = "Select account_id from user_table where user_id=?";
	public static final String selectAddressMobile = "select Address,MobileNumber from CUSTOMER where Account_ID =?";
	public static final String updateAddressMobile ="Update customer SET Address=? , MobileNumber=? where Account_ID=(Select Account_ID from user_table where User_id=?)";
	public static final String insertServiceTracker = "INSERT into SERVICE_TRACKER values(Serv_id.NEXTVAL,?,?,sysdate,'Open')";
	public static final String selectServiceId = "select Serv_id.currval from SERVICE_TRACKER";
	public static final String selectServiceStatus = "Select Service_status from Service_Tracker where service_id=? and Account_ID =?";
	public static final String selectTpandAccountId = "select * from User_Table where user_id=?";
	public static final String selectBalance = "select * from Account_Master where Account_ID=?";
	public static final String selectPayeeAccount="select * from Payee_Table where Account_ID=?";
	public static final String selectCustomerName = "select Customer_Name from customer where Account_ID = ?";
	public static final String insertFundTransfer = "insert into Fund_Transfer values(Fundtrans_id.nextval,?,?,sysdate,?)";
	public static final String insertTransaction = "insert into Transactions values(tran_id.nextval,'Deposit',sysdate,'D',?,?)";
	public static final String updateLoginPassword = "Update User_Table SET Login_Password = ? where user_id  = ?";
	public static final String selectAllFromTransaction = "select * from Transactions where Account_No=? and sysdate-DateofTransaction<=?";
	public static final String insertIntoCustomer = "insert into Customer(Account_ID,Customer_Name,Email,Address,MobileNumber) values(acc_seq.nextval,?,?,?,?)";
	public static final String insertIntoAccountMaster = "insert into Account_Master values(acc_seq.currval,?,?,sysdate)";
	public static final String insertIntoUserTable = "insert into user_table values(acc_seq.currval,user_seq.nextval,'newbee',?,?,'trannew','N','user')";
	public static final String selectAccSeq = "select acc_seq.currval from dual";

}
