package com.capg.project.dao;

import com.capg.project.bankexception.OnlineBankingException;

public interface ILockStatusDAO {

	public int lockAccount(String userId) throws OnlineBankingException;
}
