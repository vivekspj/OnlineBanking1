package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.dbutil.DBUtil;

public class LockStatusDAOImpl implements ILockStatusDAO {

	static Logger log = Logger.getRootLogger(); 
	int n=0;
	@Override
	public int lockAccount(String userId) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		try
		{
			PreparedStatement pst = conn.prepareStatement(IQueryMapper.lockAccount );
			pst.setString(1, userId);
			n = pst.executeUpdate();
		}
		catch(SQLException e){
			log.error("Account is locked.");
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return n;
	}

}
