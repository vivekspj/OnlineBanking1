package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;
import com.capg.project.dbutil.DBUtil;

public class LoginDAOImpl implements ILoginDAO {

	static Logger log = Logger.getRootLogger();
	ResultSet rs=null;
	int n=5;
	@Override
	public int login(LoginBean login1) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		String type="";
		String status = "";
		long balance=0;int wu=0,wp=0;
		try{
			PreparedStatement pst = conn.prepareStatement("select User_ID from user_table");
			ResultSet rs1= pst.executeQuery();
			while(rs1.next())
			{
				if((login1.getUserName()).equals(rs1.getString(1)))
				{
					wu=1;
					break;
				}
			}
			if(wu==1)
			{
				PreparedStatement pst2 = conn.prepareStatement("select Login_Password from user_table where User_ID = ?");
				pst2.setString(1,login1.getUserName());
				ResultSet rs2= pst2.executeQuery();
				while(rs2.next())
				{
					if((login1.getPassword()).equals(rs2.getString(1)))
					{
						wp=1;
						break;
					}
				}
				if(wp==1)
				{
					PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.login);
					pstmt.setString(1, login1.getUserName());
					pstmt.setString(2, login1.getPassword());
					rs=pstmt.executeQuery();
					while(rs.next())
					{
						type=rs.getString(8);
						status = rs.getString(7);
						
					}
					if("admin".equalsIgnoreCase(type))
					{
						
						if("n".equals(status))
						{
							n=1;
						}
						else
						{
							n=7;
						}
						
					}
					else if("user".equalsIgnoreCase(type))
					{
						if("n".equals(status))
						{
							n=0;
						}
						else
						{
							n=9;
						}
					}
					/*else
					{
						n=-1;
					}*/
					if(n==0)
					{
						PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.selectAmount);
						pstmt1.setString(1, login1.getUserName());
						ResultSet rs4 = pstmt1.executeQuery();
						while(rs4.next())
						{
							balance = rs4.getLong(1);
						}
						login1.setBalance(balance);
					}
				}
				else
				{
					PreparedStatement pstmt = conn.prepareStatement("select * from User_Table where User_Id=?");
					pstmt.setString(1, login1.getUserName());
					ResultSet rs3=pstmt.executeQuery();
					while(rs3.next())
					{
						type=rs3.getString(8);
						status = rs3.getString(7);
						
					}
					if("admin".equalsIgnoreCase(type))
					{
						
						if("n".equals(status))
						{
							n=6;
						}
						else
						{
							n=7;
						}
						
					}
					else if("user".equalsIgnoreCase(type))
					{
						if("n".equals(status))
						{
							n=8;
						}
						else
						{
							n=9;
						}
					}
				}
				/*PreparedStatement pst2 = conn.prepareStatement("select Login_Password from user_table where User_ID = ?");*/
				
			}
			else
			{
				n=4;
			}
			
			
		}
		catch(SQLException e1){
			log.error("Login failed.");
			throw new OnlineBankingException("problem : "+e1.getMessage());
			
		}
		return n;
	}
}

