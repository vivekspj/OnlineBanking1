package com.capg.project.bean;

public class LoginBean {
	
	private String userName;
	private String password;
	private long balance;
	
	
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public LoginBean(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public LoginBean() {
	
	}
	
	

}
