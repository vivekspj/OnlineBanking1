package com.capg.project.bean;

import java.util.Date;

public class BankUser {
	private int transaction_ID ;
	private String tran_Description;
	private Date dateofTransaction ;
	private String transactionType;
	private int cusid;
	private long transferAmount;
	private int balance;
	private String cusname;
	private String cusaddr;
	private String MobileNumber;
	private String serviceDescription;
	private String userName;
	private String password;
	private int payeeAccount;
	private String nickname;
	private int serviceId;
	private int tranDuration;
	
	 
	 public int getTranDuration() {
		return tranDuration;
	}
	public void setTranDuration(int tranDuration) {
		this.tranDuration = tranDuration;
	}
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public int getTransaction_ID() {
		return transaction_ID;
	}
	public void setTransaction_ID(int transaction_ID) {
		this.transaction_ID = transaction_ID;
	}
	public String getTran_Description() {
		return tran_Description;
	}
	public void setTran_Description(String tran_Description) {
		this.tran_Description = tran_Description;
	}
	public Date getDateofTransaction() {
		return dateofTransaction;
	}
	public void setDateofTransaction(Date dateofTransaction) {
		this.dateofTransaction = dateofTransaction;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	 
	 
	public int getPayeeAccount() {
		return payeeAccount;
	}
	public void setPayeeAccount(int payeeAccount) {
		this.payeeAccount = payeeAccount;
	}
	public long getTransferAmount() {
		return transferAmount;
	}
	public void setTransferAmount(long transferAmount) {
		this.transferAmount = transferAmount;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userid) {
		this.userName = userid;
	}
	public String getPassword() {
		return password;
	}
	public BankUser() {
		
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getCusid() {
		return cusid;
	}
	public void setCusid(int cusid) {
		this.cusid = cusid;
	}
	public String getCusname() {
		return cusname;
	}
	public void setCusname(String cusname) {
		this.cusname = cusname;
	}
	public String getCusaddr()
	{
		return cusaddr;
	}
	public void setCusaddr(String cusaddr)
	{
		this.cusaddr=cusaddr;
	}
	public int getBal() {
		return balance;
	}
	public void setBal(int balance) {
		this.balance = balance;
	}
	
	
	public BankUser(String cusaddr, String mobileNumber) {
		super();
		this.cusaddr = cusaddr;
		MobileNumber = mobileNumber;
	}
	public BankUser(int cusid, int balance, String cusname, String cusaddr,
			String mobileNumber, String serviceDescription, String userName,
			String password) {
		super();
		this.cusid = cusid;
		this.balance = balance;
		this.cusname = cusname;
		this.cusaddr = cusaddr;
		MobileNumber = mobileNumber;
		this.serviceDescription = serviceDescription;
		this.userName = userName;
		this.password = password;
	}
	public String getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(String MobileNumber) {
		this.MobileNumber = MobileNumber;
	}
	public String getServiceDescription() {
		return serviceDescription;
	}
	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}
}
