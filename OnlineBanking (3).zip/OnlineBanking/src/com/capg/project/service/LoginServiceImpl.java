package com.capg.project.service;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;
import com.capg.project.dao.ILoginDAO;
import com.capg.project.dao.LoginDAOImpl;

public class LoginServiceImpl implements ILoginService {

	ILoginDAO dao = new LoginDAOImpl();
	@Override
	public int login(LoginBean login1) throws OnlineBankingException {
		// TODO Auto-generated method stub
		return dao.login(login1);
	}

}
