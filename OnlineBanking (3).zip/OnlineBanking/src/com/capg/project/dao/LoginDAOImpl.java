package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.LoginBean;
import com.capg.project.dbutil.DBUtil;

public class LoginDAOImpl implements ILoginDAO {

	ResultSet rs=null;
	int n=0;
	@Override
	public int login(LoginBean login1) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		String type="";
		long balance=0;
		try{
			PreparedStatement pstmt = conn.prepareStatement("Select * from User_Table where user_id=? and login_password=?");
			pstmt.setString(1, login1.getUserName());
			pstmt.setString(2, login1.getPassword());
			rs=pstmt.executeQuery();
			while(rs.next())
			{
				type=rs.getString(8);
			}
			if("admin".equalsIgnoreCase(type))
			{
				n=1;
			}
			else if("user".equalsIgnoreCase(type))
			{
				n=0;
			}
			else
			{
				n=-1;
			}
			if(n==0)
			{
				PreparedStatement pstmt1 = conn.prepareStatement("select Account_Balance from ACCOUNT_MASTER where Account_ID = (select Account_ID from user_table where User_ID = ?)");
				pstmt1.setString(1, login1.getUserName());
				rs = pstmt1.executeQuery();
				while(rs.next())
				{
					balance = rs.getLong(1);
				}
				login1.setBalance(balance);
			}
			
		}
		catch(SQLException e1){
			throw new OnlineBankingException("problem : "+e1.getMessage());
			
		}
		return n;
	}
}

