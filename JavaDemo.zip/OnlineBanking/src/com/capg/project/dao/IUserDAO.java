package com.capg.project.dao;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;

public interface IUserDAO {
	 public abstract int login(String userid,String password) throws OnlineBankingException;
	 public abstract int changeInCommunicationAddress(BankUser bu3) throws OnlineBankingException;
	 public abstract int changeInCommunicationAddress(String userid, String addr, String number) throws OnlineBankingException;
	 public abstract int chequeBookRequest(String userid,String desc) throws OnlineBankingException;
	 public abstract String trackServiceRequest(BankUser bu2) throws OnlineBankingException;
	 public abstract int fundTransfer(String userid,BankUser bu1,AdminUser au1) throws OnlineBankingException;
	 public abstract int changePassword(String newpassword,String userid) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewMiniStatement(String userid,int tranDuration) throws OnlineBankingException;
}
