package com.capg.project.ui;

import java.util.*;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.service.AdminServiceImpl;
import com.capg.project.service.IAdminService;
import com.capg.project.service.IUserService;
import com.capg.project.service.UserServiceImpl;

public class MainMethod  {

	static int count=0;
	public static void main(String[] args) throws OnlineBankingException {
		
		BankUser bu = new BankUser();
		AdminUser au = new AdminUser();
		IUserService service=new UserServiceImpl();
		IAdminService service1 = new AdminServiceImpl();
		
		 int i;
		 String newpassword;
		 String oldpassword;String pass,userid;
		 int n=0;
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		do{
			//Read Username from user
			System.out.println("Enter UserName:");
			userid=sc.next();
			bu.setUserName(userid);
			//Read Password from user
			System.out.println("Enter Password:");
			pass=sc.next();
			//setting password to bean object
			bu.setPassword(pass);
			
			try {
				if(service.login(userid,pass)==0)
				{
					
					char j='N';
					do {//Displaying  the Menu
						System.out.println("Login Successful");
						System.out.println("1. Change In Communication Address:");
						System.out.println("2. Request For Cheque Book:");
						System.out.println("3. Track  Service Request:");
						System.out.println("4. Fund Transfer:");
						System.out.println("5. Change Password:");
						
						System.out.println("6. Mini Statement:");
						System.out.println("Enter your choice: ");
						i=sc.nextInt();
						switch(i) 
						{
							case 1:
								String number="";boolean num = false;boolean address = false;
								BankUser bu3 = new BankUser();String addr="";
								System.out.println("Your Communication Address is:");
								bu3.setUserName(userid);
								service.changeInCommunicationAddress(bu3);/*Calling the changeInCommunicationAddress from service layer*/
								System.out.println("Your current address id:"+bu3.getCusaddr());
								System.out.println("Your current mobile number is:"+bu3.getMobileNumber());
								do{
									System.out.println("Enter New Address");
									addr = sc.next();
									if(addr.matches("[0-9a-zA-Z\t]+"))
									{
										System.out.println("Enter New MobileNumber");
										do{
											number = sc.next();
											//Mobile Number Validation
											if(number.length()==10)
											{
												num=number.matches("[0-9]+");
												if(num==true)
												{
													n = service.changeInCommunicationAddress(userid,addr,number);
													System.out.println(n+" Row Updated");
												}
												else
												{
													System.out.println("Please enter only Number:");
												}
											}
											else
											{
												System.out.println("Please enter 10 digit number:");
											}
									
										}while(number.length()!=10 || num==false);
									}
									else
									{
										System.out.println("Please enter valid address");
									}
									
									
								}while(addr.matches("[a-zA-Z\t]+") == false);
								
								break;
								
							case 2:String desc="";
								System.out.println("Enter desc");
								desc = sc.next();
								System.out.println("Your Service request is generated and "
									+ "your service_id is "+service.chequeBookRequest(userid,desc));
								break;
							case 3:int sid=0;
								String status="";
								do{
									System.out.println("Enter Your Serviceid:");
									sid=sc.nextInt();
									BankUser bu2 = new BankUser();
									bu2.setServiceId(sid);
									bu2.setUserName(userid);
									status = service.trackServiceRequest(bu2);
									if(status != null)
									{
										System.out.println("Status is: "+ status);
									}
									if(status == null)
									{
										System.out.println("please enter your serviceTracker ID");
									}
								}while(status == null);
								
									
								break;
							
							case 4:long transferAmount=0;int payeeAccount_id=0;
							BankUser bu1= new BankUser();
								System.out.println("Enter PayeeAccount :");
								payeeAccount_id=sc.nextInt();
								bu1.setPayeeAccount(payeeAccount_id);
								System.out.println("Enter Amount to be transfered:");
								transferAmount=sc.nextInt();
								bu1.setTransferAmount(transferAmount);
								System.out.println("Enter Transaction_Password:");
								String transaction_Password = sc.next();
								au.setTransactionpassword(transaction_Password);
								n=service.fundTransfer(userid,bu1,au);
								System.out.println(n+ " Rows Updated.");
								break;
							
							case 5:String newpassword1="";
								System.out.println("Enter old Password:");
								oldpassword=sc.next();
								System.out.println("Enter new Password:");
								newpassword=sc.next();
								System.out.println("Enter new Password:");
								newpassword1=sc.next();
								if(newpassword1.equals(newpassword) && oldpassword.equals(pass))
								{
									
									userid=bu.getUserName();
									n=service.changePassword(newpassword,userid);
									System.out.println(n+" Row Updated.");
								}
								else
								{
									System.out.println("Both newpassword didn't match");
								}
						   
						    break;
							case 6:
								System.out.println("Select Statement Duration:");
								System.out.println("1. Press 1 for Weekly(Mini) Statement");
								System.out.println("2. Press 1 for Monthly(Detailed) Statement");
								System.out.println("3. Press 1 for Yearly(Detailed) Statement");
								int duration=sc.nextInt();
								int tranDuration=0;
								switch(duration)
								{
								case 1: tranDuration=10;
								break;
								
								case 2: tranDuration=30;
								break;
								
								case 3: tranDuration=365;
								break;
								}
								ArrayList<BankUser> al = new ArrayList<BankUser>();
								al = service.viewMiniStatement(userid, tranDuration);
								
								/* Iterator itr=al.iterator();  
								  while(itr.hasNext()){  
								   System.out.println(itr.next());  
								  } */
								System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
										+ "TransactionType |  TranAmount  |  Account_No");
								System.out.println("----------------------------------------------------------"
										+ "------------------------------------------");
								for(BankUser b:al)
								{
									System.out.println(b.getTransaction_ID()+" 		|	"+b.getTran_Description()
											+"	 |	"+b.getDateofTransaction()+"	|	"+b.getTransactionType()
											+"	 |	"+b.getTransferAmount()+"  	|	"+b.getCusid());
								}
								break;
							default: System.out.println("Thanks for Visiting");
							break;
						}
						
						System.out.println("Press 'Y' to continue and 'N' to exit");
						j=sc.next().charAt(0);
					}while(j == 'Y' || j=='y');

				}
				else if(service.login(userid,pass)==1)
				{
					char j='N';
					do{
						System.out.println("1. Create New Account:");
						System.out.println("2. View transactions of all accounts:");
						i=sc.nextInt();
						switch(i) 
						{
						case 1:String customerName="",customeremail="",customeraddress="",mobileNumber="";
								System.out.println("Enter Your name");
								customerName=sc.next();
								System.out.println("Enter Your Email");
								customeremail=sc.next();
								System.out.println("Enter Your Address");
								customeraddress=sc.next();
								System.out.println("Enter Your Mobile number");
								boolean num = false;
								String accountType="";
								do{
									mobileNumber=sc.next();
									if(mobileNumber.length()==10)
									{
										num=mobileNumber.matches("[0-9]+");
										if(num==true)
										{
											au.setCustomerName(customerName);
											au.setCustomeremail(customeremail);
											au.setCustomeraddress(customeraddress);
											au.setMobileNumber(mobileNumber);
											
											
											int openingBalance;
											System.out.println("Enter aacount_type Saving/Current");
											
											do{
												accountType=sc.next();
												if(accountType.equalsIgnoreCase("saving") || accountType.equalsIgnoreCase("deposit"))
												{
													au.setAccountType(accountType);
													System.out.println("Enter Opening balance");
													openingBalance=sc.nextInt();
													if(openingBalance>=0)
													{
														au.setOpeningBalance(openingBalance);
														String securityQuestion="",securityAnswer="";
														System.out.println("Enter Security question and answer");
														securityQuestion=sc.next();
														securityAnswer=sc.next();
														au.setSecurityQuestion(securityQuestion);
														au.setSecurityAnswer(securityAnswer);
														int account_id = service1.createNewAccount(au);
														System.out.println("Your Account Id id "+account_id);
													}
													else
													{
														System.err.println("Please enter valid Balance");
													}
													
												}
												else
												{
													System.err.println("Either enter saving or deposit");
												}
											}while(!accountType.equalsIgnoreCase("saving") || !accountType.equalsIgnoreCase("current"));
											
										}
										else
										{
											System.out.println("Please enter only Number:");
										}
									}
									else
									{
										System.out.println("Please enter 10 digit number:");
									}
									
									
								}while(mobileNumber.length()!=10 || num ==false);
							
							break;
							
						case 2:int account_id1=0,duration=0;
						BankUser bu1 = new BankUser();
								System.out.println("Enter Account Id for getting Transaction of accountid");
								account_id1 = sc.nextInt();
								System.out.println("Select Duration:");
								System.out.println("1. Weekly");
								System.out.println("2. Monthly");
								System.out.println("3. Yearly");
								duration=sc.nextInt();
								int tranDuration=0;
								switch(duration)
								{
								case 1: tranDuration=7;
								
								break;
								
								case 2: tranDuration=30;
								break;
								
								case 3: tranDuration=365;
								break;
								
								default: System.out.println("please select proper duration.");;
								break;
								}
								ArrayList<BankUser> al = new ArrayList<BankUser>();
								al = service1.viewTransaction(account_id1, tranDuration);
								
								/* Iterator itr=al.iterator();  
								  while(itr.hasNext()){  
								   System.out.println(itr.next());  
								  } */
								System.out.println("Transaction_ID | Tran_Description | DateofTransaction | "
										+ "TransactionType |  TranAmount  |  Account_No");
								System.out.println("----------------------------------------------------------"
										+ "------------------------------------------");
								for(BankUser b1:al)
								{
									System.out.println(b1.getTransaction_ID()+" 		|	"+b1.getTran_Description()
											+"	 |	"+b1.getDateofTransaction()+"	|	"+b1.getTransactionType()
											+"	 |	"+b1.getTransferAmount()+"  	|	"+b1.getCusid());
								}
							
							break;
							
						default: System.out.println("Thanks for Visiting");
							
							break;
						}
						System.out.println("Press 'Y' to continue and 'N' to exit");
						j=sc.next().charAt(0);
					}while(j == 'Y' || j=='y');
					
					
				}
				else
				{
					++count;
					int left=3-count;
					if(count<3)
					{
						System.out.println("Incorrect Username or Password.");
						System.out.println("You have Entered Wrong UserName and Password "+count +" Time.");
						System.out.println("Your Account Will be Locked After "+left+" Attempts.");
						System.out.println("Please Enter Correct UserName and Password.");
					}
					if(count==3)
					{
						System.out.println("Your Account is Blocked. Please Contact Your Nearest Branch.");
					}
					
				}
			} catch (OnlineBankingException e) {
				
				throw new OnlineBankingException("problem : "+e.getMessage());
			}
			
			
		}while(count>0 && count<3);
		
	}
	
}

