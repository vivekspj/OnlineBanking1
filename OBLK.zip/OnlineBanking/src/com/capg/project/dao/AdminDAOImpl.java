package com.capg.project.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;
import com.capg.project.dbutil.DBUtil;

public class AdminDAOImpl implements IAdminDAO {

	int n=0;
	ResultSet rs = null;
	@Override
	public int createNewAccount(AdminUser au) throws OnlineBankingException {
		Connection conn=DBUtil.getConn();
		int aid;
		try{
			PreparedStatement pstmt = conn.prepareStatement("insert into Customer values(acc_seq.nextval,?,?,?,'null',?)");
			pstmt.setString(1, au.getCustomerName());
			pstmt.setString(2,au.getCustomeremail());
			pstmt.setString(3,au.getCustomeraddress());
			pstmt.setString(4, au.getMobileNumber());
			
			 n = pstmt.executeUpdate();
			 
			 PreparedStatement pstmt1 = conn.prepareStatement("insert into Account_Master values(acc_seq.currval,?,?,sysdate)");
			 pstmt1.setString(1,au.getAccountType());
			 pstmt1.setInt(1,au.getOpeningBalance());
			 
			n= n+ pstmt1.executeUpdate();
			 PreparedStatement pstmt3 = conn.prepareStatement("insert into user_table values(acc_seq.currval,user_seq.nextval,'newbee',?,?,'trannew','N','user')");
			 
			 
			 n=n+pstmt3.executeUpdate();
			 
			 PreparedStatement pstmt2 = conn.prepareStatement("select acc_seq.currval from dual");
			 aid = pstmt2.executeUpdate();
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		return aid;
	}

	@Override
	public ArrayList<BankUser> viewTransaction(int account_id,int tranDuration) throws OnlineBankingException
	{
		Connection conn=DBUtil.getConn();
		ArrayList<BankUser> al = new ArrayList<BankUser>();
		BankUser bu1 = new BankUser();
		try{
			PreparedStatement pstmt = conn.prepareStatement("select * from Transactions where Account_No=? and sysdate-DateofTransaction<=?");
			pstmt.setInt(1,account_id);
			pstmt.setInt(2,tranDuration);
			rs=pstmt.executeQuery();
			while(rs.next()){
				int transaction_ID = rs.getInt(1);
				String tran_Description = rs.getString(2);
				Date dateofTransaction = rs.getDate(3);
				String transactionType = rs.getString(4);
				int transferAmount = rs.getInt(5);
				int account_No = rs.getInt(6);
				bu1.setTransaction_ID(transaction_ID);
				bu1.setTran_Description(tran_Description);
				bu1.setDateofTransaction(dateofTransaction);
				bu1.setTransactionType(transactionType);
				bu1.setCusid(account_No);
				bu1.setTransferAmount(transferAmount);
				al.add(bu1);
			}
			
		}
		catch(SQLException e){
			throw new OnlineBankingException("problem : "+e.getMessage());
		}
		
		
		return al;
	}


}
