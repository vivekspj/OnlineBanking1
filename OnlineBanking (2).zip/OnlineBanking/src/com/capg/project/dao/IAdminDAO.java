package com.capg.project.dao;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.AdminUser;
import com.capg.project.bean.BankUser;



public interface IAdminDAO {
	public abstract int createNewAccount(AdminUser au) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewTransaction(int account_id1,int tranDuration) throws OnlineBankingException;

}
